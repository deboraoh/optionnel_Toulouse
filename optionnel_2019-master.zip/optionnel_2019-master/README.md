# optionnel_2019
matériel pour l'enseignement optionnel des DQPRM 2017-2019
## Programme
--------------------
|10 Septembre 2019|	 |
|----|---|
|9h30-10h|Accueil - finalisation des installations|
|10h-10h15|Introduction générale|
|10h15-10h30| Table ronde, discussion sur la notion de reproductibilité en science|
|10h30-12h30|Introduction à python et début projet python|
|12h30-14h|Pause déjeuner|
|14h-14h30|Courte introduction à un système de versioning de code : git|
|14h30-17h30|Suite projet python, utilisation de git|

|11 Septembre 2019|	 |
|----|---|
|9h00-12h|Projet DB analyses d'images avec Python|
|12h-13h|Pause déjeuner|
|13h-14h| Introduction Literate programming et machine learning|
|14h-16h|Suite projet|